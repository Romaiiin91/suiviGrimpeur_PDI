/* ------------------------------------------------------------------------ */
/*                       Suivi grimpeur - Positions                         */
/*                        Auteur : CHEVALIER Romain                         */
/*                            Date : 26-10-2024                             */
/* ------------------------------------------------------------------------ */


/* ------------------------------------------------------------------------ */
/*                      M A C R O - F O N C T I O N S                       */
/* ------------------------------------------------------------------------ */

#ifndef __CHECK_MACRO__

#ifdef DEBUG
    #define DEBUG_PRINT(msg, ...) printf(msg, ##__VA_ARGS__)
#else
    #define DEBUG_PRINT(msg, ...) // Ne fait rien si DEBUG n'est pas défini
#endif



#define CHECK_T(status, msg)                                                 \
  if (0 != (status))   {                                                     \
    fprintf(stderr, "pthread erreur : %s avec erreur n°%d\n", msg, status);  \
    exit (EXIT_FAILURE);                                                     \
  }

#define CHECK(status, msg)                                                   \
    if (-1 == (status)) {                                                    \
        perror(msg);                                                         \
        exit(EXIT_FAILURE);                                                  \
    }

#define CHECK_NULL(status, msg)                                              \
    if (NULL == (status)) {                                                  \
        perror(msg);                                                         \
        exit(EXIT_FAILURE);                                                  \
    }

    #define __CHECK_MACRO__
#endif

/* ------------------------------------------------------------------------ */
/*                   E N T Ê T E S    S T A N D A R D S                     */
/* ------------------------------------------------------------------------ */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> 

#include <string.h>
#include <ncurses.h>
#include <menu.h>
#include <curl/curl.h>


/* ------------------------------------------------------------------------ */
/*              C O N S T A N T E S     S Y M B O L I Q U E S               */
/* ------------------------------------------------------------------------ */

#define SCRIPT_PTZ          "http://serveur:serveur@192.168.1.48/axis-cgi/com/ptz.cgi?"
#define SCRIPT_POS_PTZ      "http://serveur:serveur@192.168.1.48/axis-cgi/com/ptz.cgi?query=position"
#define FILEPATH_POSITIONS  "./positionsEnregistrees.tkt"
#define LONGUEUR_LIGNE_FILE 35

#define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))

/* ------------------------------------------------------------------------ */
/*              D É F I N I T I O N S   D E   T Y P E S                     */
/* ------------------------------------------------------------------------ */

typedef struct{
    int numVoie;
    double pan, tilt, zoom;
} positionPTZ;

struct MemoryStruct {
  char *memory;
  size_t size;
};




/* ------------------------------------------------------------------------ */
/*            P R O T O T Y P E S    D E    F O N C T I O N S               */
/* ------------------------------------------------------------------------ */

static size_t writeMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp);
void enregistrerPosition();
void addPositionFile(const positionPTZ pos);
void allerPosition(positionPTZ pos);
void choixPosition();
double recupererValeur(const char *data, const char *key);
void supprimerPositionFile();




