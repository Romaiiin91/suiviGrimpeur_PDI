/* ------------------------------------------------------------------------ */
/*                            Suivi grimpeur                                */
/*                        Auteur : CHEVALIER Romain                         */
/*                            Date : 26-10-2024                             */
/* ------------------------------------------------------------------------ */



/* ------------------------------------------------------------------------ */
/*                   E N T Ê T E S    S T A N D A R D S                     */
/* ------------------------------------------------------------------------ */

#include <stdio.h>
#include <stdlib.h>
#include <unistd.h> 

#include <signal.h>
#include <bits/sigaction.h> // Include pour evider les erreurs sur vscode 
#include <bits/types/sigset_t.h>


#include <sys/wait.h>

#include <string.h>
#include <ncurses.h>
#include <menu.h>
#include <curl/curl.h>

#include <positions.h>


/* ------------------------------------------------------------------------ */
/*              C O N S T A N T E S     S Y M B O L I Q U E S               */
/* ------------------------------------------------------------------------ */

#define ENTETE_HTTP         "http://"
#define USER_MDP            "serveur:serveur"
#define IP                  "192.168.1.48"
#define SCRIPT_VIDEO        "http://serveur:serveur@192.168.1.48/axis-cgi/mjpg/video.cgi?resolution=1280x720&fps=25&compression=25"
#define NB_ARGS_VIDEO       10
#define SCRIPT_PTZ          "http://serveur:serveur@192.168.1.48/axis-cgi/com/ptz.cgi?"
#define SCRIPT_POS_PTZ      "http://serveur:serveur@192.168.1.48/axis-cgi/com/ptz.cgi?query=position"
#define PATH_POS_SAVED      "./positionsEnregistrees.tkt"

#define ARRAY_SIZE(a) (sizeof(a) / sizeof(a[0]))



/* ------------------------------------------------------------------------ */
/*              D É F I N I T I O N S   D E   T Y P E S                     */
/* ------------------------------------------------------------------------ */


/* ------------------------------------------------------------------------ */
/*                      M A C R O - F O N C T I O N S                       */
/* ------------------------------------------------------------------------ */

#ifndef __CHECK_MACRO__

#ifdef DEBUG
    #define DEBUG_PRINT(msg, ...) printf(msg, ##__VA_ARGS__)
#else
    #define DEBUG_PRINT(msg, ...) // Ne fait rien si DEBUG n'est pas défini
#endif



#define CHECK_T(status, msg)                                                 \
  if (0 != (status))   {                                                     \
    fprintf(stderr, "pthread erreur : %s avec erreur n°%d\n", msg, status);  \
    exit (EXIT_FAILURE);                                                     \
  }

#define CHECK(status, msg)                                                   \
    if (-1 == (status)) {                                                    \
        perror(msg);                                                         \
        exit(EXIT_FAILURE);                                                  \
    }

#define CHECK_NULL(status, msg)                                              \
    if (NULL == (status)) {                                                  \
        perror(msg);                                                         \
        exit(EXIT_FAILURE);                                                  \
    }

    #define __CHECK_MACRO__
#endif


/* ------------------------------------------------------------------------ */
/*                 V A R I A B L E S    G L O B A L E S                     */
/* ------------------------------------------------------------------------ */

pid_t pidCapture;


char *choices[] = {
    "Lancer l'enregistrement", 
    "Stopper l'enregistrement", 
    "Mouvement",
    "Enregistrer cette position pour une voie",
    "Supprimer une voie",
    "Allez a une voie", 
    (char *) NULL,
}; 



/* ------------------------------------------------------------------------ */
/*            P R O T O T Y P E S    D E    F O N C T I O N S               */
/* ------------------------------------------------------------------------ */

void bye();
void processusCapture(const char *outputVideoFile);
static void signalHandler(int numSig);
void deplacement();
void requetePTZ(const char *cmd, const char *val);
void enregistrerPosition();
void allerPosition(positionPTZ pos);


/* ------------------------------------------------------------------------ */
/*            D E F I N I T I O N   D E    F O N C T I O N S                */
/* ------------------------------------------------------------------------ */

int main(int argc, char const *argv[])
{
    //Installation du gestionnaire de fin d'exécution du programme
	atexit(bye);

	// Installation du gestionnaire de signaux pour géré le ctrl c et la fin d'un fils.
    struct sigaction newAction;
    newAction.sa_handler = signalHandler;
    CHECK(sigemptyset(&newAction.sa_mask ), " sigemptyset ()");
    newAction.sa_flags = 0;
    CHECK(sigaction(SIGINT, &newAction, NULL), "sigaction (SIGINT)");
    CHECK(sigaction(SIGCHLD, &newAction, NULL), "sigaction (SIGCHLD)");


 
    char outputVideoFile[22]="./videos/test.mp4";
    pid_t pidFils;

    
	
     // Initialisation de ncurses
    ITEM **my_items;
    MENU *my_menu;
    int c;
    ITEM *cur_item;
    initscr();
    cbreak();
    noecho();
    keypad(stdscr, TRUE);

    // Création des items du menu
    int n_choices = ARRAY_SIZE(choices) - 1; // -1 pour exclure NULL

    my_items = (ITEM **)calloc(n_choices + 1, sizeof(ITEM *)); // +1 pour le NULL final

    for (int i = 0; i < n_choices; i++) my_items[i] = new_item(choices[i], "");
    my_items[n_choices] = (ITEM *)NULL; // Marquer la fin des éléments

    // Créer le menu
    my_menu = new_menu((ITEM **)my_items);
    mvprintw(LINES - 2, 0, "Appuyez sur 'q' pour quitter");
    post_menu(my_menu);
    refresh();

   while ((c = getch()) != 'q') {
        switch (c) {
            case KEY_DOWN:
                menu_driver(my_menu, REQ_DOWN_ITEM);
                break;
            case KEY_UP:
                menu_driver(my_menu, REQ_UP_ITEM);
                break;
            case 10: // Touche 'Enter'
                {
                    const char *selected_choice = item_name(current_item(my_menu));

                    if (strcmp(selected_choice, choices[0]) == 0) {
                        CHECK(pidFils = fork(), "fork(pidCapture)");
                        if (pidFils == 0) {
                            processusCapture(outputVideoFile);
                        } else {
                            pidCapture = pidFils;
                        }
                        mvprintw(LINES - 3, 0, "Enregistrement en cours");
                    } else if (strcmp(selected_choice, choices[1]) == 0) {
                        if (pidCapture > 0) {
                            kill(pidCapture, SIGTERM); // Arrête le processus de capture
                            pidCapture = -1;
                        }
                        mvprintw(LINES - 3, 0, "                                          ");
                    } else if (strcmp(selected_choice, choices[2]) == 0){
                        mvprintw(LINES - 4, 0, "Option de déplacement sélectionnée,(q pour quitter)");
                        mvprintw(LINES - 5, 0, "Flèches pour naviguer et page UP/DOWN pour le zoom");
                        deplacement();
                        mvprintw(LINES - 4, 0, "                                                         ");
                        mvprintw(LINES - 5, 0, "                                                         ");
                    } 
                    else if (strcmp(selected_choice, choices[3]) == 0) {
                        unpost_menu(my_menu);
                        clear();
                        refresh();
                        enregistrerPosition();
                        clear();
                
                        post_menu(my_menu);
                        mvprintw(LINES - 2, 0, "Appuyez sur 'q' pour quitter");
                        refresh();
                    }
                    else if (strcmp(selected_choice, choices[4]) == 0) {
                        unpost_menu(my_menu);
                        clear();
                        refresh();
                        supprimerPositionFile();
                        clear();
                        post_menu(my_menu);
                        mvprintw(LINES - 2, 0, "Appuyez sur 'q' pour quitter");
                        refresh();
                    }
                    else if (strcmp(selected_choice, choices[5]) == 0) {
                        unpost_menu(my_menu);
                        clear();
                        refresh();
                        choixPosition();
                        clear();
                        post_menu(my_menu);
                        mvprintw(LINES - 2, 0, "Appuyez sur 'q' pour quitter");
                        refresh();
                    }
                }
                break;
        }
        refresh();
    
        // Rafraîchir l'écran pour mettre à jour l'affichage
        wrefresh(stdscr);
    }

    // Nettoyage
    unpost_menu(my_menu);
    free_menu(my_menu);
    for (int i = 0; i < n_choices; ++i) {
        free_item(my_items[i]);
    }
    free(my_items);
    
    


    return 0;
}


void processusCapture(const char *outputVideoFile){

    DEBUG_PRINT("\t[%d] --> Début de la capture\n", getpid());


    // Url du flux
    // -y force overwrite
    char *args[NB_ARGS_VIDEO+1] = {"ffmpeg", "-y", "-loglevel", "0",  "-i", SCRIPT_VIDEO, "-c", "copy", NULL, NULL, NULL};
    args[8] = strdup(outputVideoFile);

#ifdef DEBUG
    for (int i = 0; i<NB_ARGS_VIDEO;i++){
        //printf("args[%d] = %s\n", i, args[i]);
    }
#endif
    execvp("ffmpeg", args);

}

static void signalHandler(int numSig)
{ 
    switch(numSig) {
        case SIGINT : // traitement de SIGINT
            printf("\t[%d] --> Arrêt du programme en cours...\n", getpid());
            exit(0); // Terminer le programme proprement
			break;
		case SIGCHLD: /* traitement de SIGCHLD */
            {
                pid_t pid;
                int status;

                // Boucle pour récupérer tous les fils terminés, afin d'éviter les processus zombies
                while ((pid = waitpid(-1, &status, WNOHANG)) > 0) DEBUG_PRINT("\t[%d] --> Arrêt de la capture, arrêt du fils de PID: %d\n", getpid(), pid);


            }
            break;
        default :
            printf (" Signal %d non traité \n", numSig );
            break ;
    }
}


void bye(){

	//DEBUG_PRINT("Fin du fils dans bye\n");

	if (pidCapture>0){ // Si le fils est encore en exécution
		kill(pidCapture, SIGTERM); // Arret du fils 
		pause(); // Attente de la fin du fils et que le signal SIGCHLD soit levé.
	}

    // Fin de ncurses
    endwin();
	
}

void deplacement(){
    int c;
    

    while ((c = getch()) != 'q') {
        switch (c) {
            case KEY_DOWN:
                requetePTZ("move","down");
                break;
            case KEY_UP:
                requetePTZ("move","up");
                break;
            case KEY_LEFT:
                requetePTZ("move","left");
                break;
            case KEY_RIGHT:
                requetePTZ("move","right");
                break;
            case KEY_PPAGE:
                requetePTZ("rzoom","500");
                break;
            case KEY_NPAGE:
                requetePTZ("rzoom","-500");
                break;
        }
}
}

void requetePTZ(const char * cmd, const char *val){
    char *requete = (char *) malloc(sizeof(char*)*80);
    sprintf(requete, "%s%s=%s", SCRIPT_PTZ, cmd, val);

    CURL *curl;
    CURLcode res;
 
    curl_global_init(CURL_GLOBAL_DEFAULT);
    curl = curl_easy_init();

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_URL, requete);  // URL de la requête
        res = curl_easy_perform(curl);  // Effectuer la requête

        // Vérification de la réussite de la requête
        if (res != CURLE_OK) fprintf(stderr, "Erreur de requête : %s\n", curl_easy_strerror(res));

        // Nettoyage
        curl_easy_cleanup(curl);
    }
    curl_global_cleanup();
}

